Reunion 是一个 Metamod 模块，它允许 p.47 和 p.48 的非 Steam 正版客户端连接到基于ReHLDS的服务器.

当前版本: 0.2.0.36
更多信息和更新，请访问：https://github.com/s1lentq/reunion

文档包含:
	amxx 目录                                 - 一些使用 reunion 功能的 AmxModX 插件示例.
	bin 目录                                    - 用于 Linux 和 Windows 的二进制文件（库）.
	public			- 供 modders 使用的 C++ API
	Readme.txt		- 本文件.
	reunion.cfg		- reunion 配置文件.

要求:
	- 基于 ReHLDS 的服务器
	- Metamod 1.20 或更高版本

安装步骤:
	1. 转到  <gamedir>/addons/ 并创建一个名为 reunion 的新目录
 		<gamedir> - 是游戏目录；Counter-Strike 为 cstrike，Half-Life 为 valve 等等
	2. 将 reunion_mm.dll 或 reunion_mm_i386.so 复制到 <gamedir>/addons/reunion/ 中
	3. 转到 Metamod 安装目录（通常是 <gamedir>/addons/metamod/）并编辑 plugins.ini 文件:
		对于 Windows 系统
			添加一行： win32 addons\reunion\reunion_mm.dll
		对于 Linux 系统
			添加一行： linux addons/reunion/reunion_mm_i386.so
		将该行添加到文件的开头
	4. 将 reunion.cfg 复制到服务器根目录或 gamedir 中.
	5. 启动服务器.当服务器加载时，在控制台中输入 "meta list"，将看到类似如下的信息:

		Currently loaded plugins:
		      description      stat pend  file              vers      src   load  unlod
		 [ 1] Reunion          RUN   -    reunion_mm_i386.  v0.2.0.22 ini   Start Never
		 [ 2] AMX Mod X        RUN   -    amxmodx_mm_i386.  v1.8.1.3  ini   Start ANY
		2 plugins, 2 running
	6. 如果状态不是 "RUN"，请使用 "+log on +mp_logecho 1" 参数重新启动服务器，并查看控制台输出.99%会找到原因.
	7. amxx 目录中的 AmxModX 插件非必须.

如何更改客户端的 SteamID
	使用 reunion.cfg 中 AUTHID MANAGEMENT 部分的 cid* 选项
	例如，如果想为不支持唯一 ID 生成的 p47 客户端分配由 IP 生成的 SteamID，应该设置为:
		cid_NoSteam47 = 3 为这些客户端分配格式为 STEAM_x:y:z 的 SteamID
		cid_NoSteam47 = 4 为这些客户端分配格式为 VALVE_x:y:z 的 SteamID

	如果想禁止这些客户端进入服务器，只需将 clientid 设置为 5，例如:
		cid_NoSteam47 = 5
	则所有没有模拟器的 p47 客户端将被禁止进服，并显示下方自定义的消息.

如何更改当客户端 ID 为 5 时的拒绝消息（已弃用）
	可以使用以下 cvar 来设置:
		dp_rejmsg_steam 为合法的 Steam (cid_Steam) 客户端
		dp_rejmsg_nosteam47 为非 Steam p47 (cid_NoSteam47) 客户端
		dp_rejmsg_nosteam48 为非 Steam p48 (cid_NoSteam48) 客户端
		dp_rejmsg_hltv 为 HLTV (cid_HLTV) 客户端
		dp_rejmsg_pending 为未授权 (cid_cid_SteamPending) 客户端
		dp_rejmsg_revemu 为 revEmu (>= 9.74 && <= 9.82) 客户端
		dp_rejmsg_steamemu 为 steamEmu 客户端
		dp_rejmsg_oldrevemu 为旧版 revEmu 客户端 (< 9.74)
		dp_rejmsg_avsmp  为 AVSMP 客户端
		dp_rejmsg_revemu_sc2009 为 revEmu (> 9.82) 和 SteamClient2009 客户端
		dp_rejmsg_sxei 为启用了 SXE Injected 的客户端，如果 EnableSXEIdGeneration 设置为 1
		dp_rejmsg_revemu2013 为 revEmu 2013 客户端

	只需将消息写入相应的 cvar，拒绝的客户端将会显示该消息.

	示例，server.cfg 的一部分:
		dp_rejmsg_nosteam47  "抱歉，检测到使用盗版，请下载正版"

如何在 AMXX 中获取客户端协议:
	查看 amxx/reu_test.sma.这是一个示例插件，当客户端连接时会输出协议编号.
	注意: 这是一个示例插件，非必须安装.

感谢:
                dreamstalker 为 ReHLDS 项目提供支持；
                所有帮助开发 dproto 的人；
                kazakh758 为修复与客户端连接时挂起相关问题提供测试；
                BombermaG 为发现查询模拟器中的一个 bug 提供帮助。